# Clean
All the necessary codes and basics of the Functional programming language Clean IDE.

